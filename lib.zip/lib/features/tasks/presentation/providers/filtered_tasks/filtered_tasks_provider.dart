import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:uptodo/features/tasks/domain/models/task_model.dart';
import 'package:uptodo/features/tasks/presentation/providers/task_list/task_list_provider.dart';
import 'package:uptodo/features/tasks/presentation/providers/task_search/task_search_provider.dart';

part 'filtered_tasks_provider.g.dart';

@riverpod
List<Task> filteredTasks(Ref ref, Filter filter) {
  final taskListState = ref.watch(taskListProvider);
  final search = ref.watch(taskSearchProvider);

  List<Task> tempTasks;

  final now = DateTime.now();
  final startOfToday = DateTime(now.year, now.month, now.day);
  final startOfTomorrow = startOfToday.add(Duration(days: 1));
  tempTasks = switch (filter) {
    Filter.today => taskListState.tasks.where((task) {
      final date = task.updatedAt;
      return (date.isAfter(startOfToday) ||
              date.isAtSameMomentAs(startOfToday)) &&
          date.isBefore(startOfTomorrow);
    }).toList(),
    Filter.completed =>
      taskListState.tasks.where((task) => task.completed).toList()
        ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt)),
    Filter.active =>
      taskListState.tasks.where((task) => !task.completed).toList()
        ..sort((a, b) {
          final aOverdue = a.updatedAt.isBefore(now);
          final bOverdue = b.updatedAt.isBefore(now);
          if (aOverdue && !bOverdue) return -1;
          if (!aOverdue && bOverdue) return 1;

          final priorityComparison = a.priority.compareTo(b.priority);
          if (priorityComparison != 0) return priorityComparison;

          return a.updatedAt.compareTo(b.updatedAt);
        }),
    Filter.all => taskListState.tasks,
  };
  if (search.isNotEmpty) {
    tempTasks = tempTasks
        .where(
          (task) => task.title.toLowerCase().contains(search.toLowerCase()),
        )
        .toList();
  }
  return tempTasks;
}
